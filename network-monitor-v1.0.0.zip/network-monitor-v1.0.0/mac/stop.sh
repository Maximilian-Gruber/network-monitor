set -e

echo "stopping network monitor services..."

docker-compose down

echo "============================="
echo "network monitor services stopped."
echo "============================="
